<?php include 'inc/header.php'; ?>
<?php include 'inc/navbar.php'; ?>

<section>
  <h2>Tentang Kami</h2>
  <p>Batik Wistara adalah produsen batik khas Indonesia dengan sentuhan modern.</p>
</section>

<?php include 'inc/footer.php'; ?>
