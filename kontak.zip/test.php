<?php echo "HTACCESS BERHASIL"; ?>
