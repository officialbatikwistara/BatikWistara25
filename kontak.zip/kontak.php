<?php include 'inc/header.php'; ?>
<?php include 'inc/navbar.php'; ?>

<section>
  <h2>Kontak Kami</h2>
  <p>Alamat: Jl. Batik No.1, Pekalongan</p>
  <p>WhatsApp: <a href="https://wa.me/6281234567890">0812-3456-7890</a></p>
  <p>Email: info@batikwistara.com</p>
</section>

<?php include 'inc/footer.php'; ?>
